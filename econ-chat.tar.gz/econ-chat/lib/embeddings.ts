import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// We use text-embedding-3-small: 1536 dimensions, $0.02 per 1M tokens,
// multilingual (handles Persian/Arabic well too). Switch to -3-large
// (3072 dim, ~6x cost) only if retrieval quality is bad.
const MODEL = 'text-embedding-3-small';

/**
 * Embed a single string. Use for query-time embedding.
 */
export async function embed(text: string): Promise<number[]> {
  const res = await openai.embeddings.create({
    model: MODEL,
    input: text,
  });
  return res.data[0].embedding;
}

/**
 * Embed many strings in one API call. The OpenAI endpoint accepts
 * up to ~2048 inputs per call, but we batch at 100 to stay safely
 * under the per-request token limit (8191 tokens per input).
 */
export async function embedBatch(texts: string[]): Promise<number[][]> {
  const out: number[][] = [];
  const BATCH = 100;
  for (let i = 0; i < texts.length; i += BATCH) {
    const slice = texts.slice(i, i + BATCH);
    const res = await openai.embeddings.create({
      model: MODEL,
      input: slice,
    });
    for (const d of res.data) out.push(d.embedding);
    // Light rate-limit friendliness.
    if (i + BATCH < texts.length) await new Promise(r => setTimeout(r, 100));
  }
  return out;
}
