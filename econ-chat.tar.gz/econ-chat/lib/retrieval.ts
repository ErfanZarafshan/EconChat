import pgvector from 'pgvector/pg';
import { pool, ensurePgvector } from './db';
import { embed } from './embeddings';

export type RetrievedChunk = {
  id: number;
  content: string;
  chapter: string | null;
  section: string | null;
  page: number | null;
  similarity: number;
};

/**
 * Find the top-k chunks from `bookId` most similar to `query`.
 *
 * The `<=>` operator is pgvector's cosine *distance* (0 = identical,
 * 2 = opposite). We convert to similarity for readability: 1 - distance.
 *
 * Why k=8? For dense math content, 5 chunks is often too few — a single
 * concept might be developed across several paragraphs. 8 is a good
 * default; tune based on how much context your prompt can hold.
 */
export async function retrieve(
  bookId: number,
  query: string,
  k = 8
): Promise<RetrievedChunk[]> {
  await ensurePgvector();
  const qVec = await embed(query);
  const res = await pool.query(
    `SELECT id, content, chapter, section, page,
            1 - (embedding <=> $1) AS similarity
     FROM chunks
     WHERE book_id = $2
     ORDER BY embedding <=> $1
     LIMIT $3`,
    [pgvector.toSql(qVec), bookId, k]
  );
  return res.rows;
}
