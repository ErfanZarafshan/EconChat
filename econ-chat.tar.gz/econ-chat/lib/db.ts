import { Pool } from 'pg';
import pgvector from 'pgvector/pg';

// Reuse one connection pool across the app. Next.js dev mode reloads
// modules on every save, so we cache the pool on globalThis to avoid
// leaking connections.
const globalForDb = globalThis as unknown as { pool?: Pool };

export const pool =
  globalForDb.pool ??
  new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 10,
  });

if (process.env.NODE_ENV !== 'production') {
  globalForDb.pool = pool;
}

// Register pgvector with the pg driver so that vector columns are
// serialized/deserialized correctly. Must be called once per pool.
let registered = false;
export async function ensurePgvector() {
  if (registered) return;
  const client = await pool.connect();
  try {
    await pgvector.registerType(client);
    registered = true;
  } finally {
    client.release();
  }
}
