import Link from 'next/link';
import { pool } from '@/lib/db';

// Server component. Runs on the server, queries Postgres, renders HTML.
// No useState, no useEffect — Next.js App Router lets us treat this like
// a backend template.
export default async function Home() {
  const res = await pool.query(
    'SELECT id, title, author, field, description FROM books ORDER BY id'
  );
  const books = res.rows;

  return (
    <main className="mx-auto max-w-3xl px-6 py-12">
      <h1 className="text-3xl font-semibold tracking-tight mb-2">Econ Library</h1>
      <p className="text-stone-600 mb-10">
        Chat with the authors of advanced economics textbooks. Each conversation
        is grounded in the book's text.
      </p>

      {books.length === 0 ? (
        <div className="rounded-lg border border-dashed border-stone-300 p-8 text-center text-stone-500">
          No books yet. Run the ingestion script:
          <pre className="mt-3 text-xs bg-stone-100 p-3 rounded text-left">
{`npx tsx scripts/ingest.ts \\
  --pdf ./books/your-book.pdf \\
  --title "..." --author "..." --field macro`}
          </pre>
        </div>
      ) : (
        <ul className="space-y-3">
          {books.map(b => (
            <li key={b.id}>
              <Link
                href={`/books/${b.id}`}
                className="block rounded-lg border border-stone-200 bg-white px-5 py-4 hover:border-stone-400 hover:shadow-sm transition"
              >
                <div className="flex justify-between items-start gap-4">
                  <div>
                    <div className="font-medium">{b.title}</div>
                    <div className="text-sm text-stone-500">{b.author}</div>
                    {b.description && (
                      <p className="mt-2 text-sm text-stone-600">{b.description}</p>
                    )}
                  </div>
                  {b.field && (
                    <span className="text-xs uppercase tracking-wider text-stone-400">
                      {b.field}
                    </span>
                  )}
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
