import { notFound } from 'next/navigation';
import Link from 'next/link';
import { pool } from '@/lib/db';
import ChatInterface from '@/components/ChatInterface';

export default async function BookPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const bookId = parseInt(id, 10);
  if (Number.isNaN(bookId)) notFound();

  const res = await pool.query(
    'SELECT id, title, author, field FROM books WHERE id = $1',
    [bookId]
  );
  if (res.rows.length === 0) notFound();
  const book = res.rows[0];

  return (
    <main className="mx-auto max-w-3xl px-6 py-8 flex flex-col h-screen">
      <header className="mb-6 pb-4 border-b border-stone-200">
        <Link href="/" className="text-sm text-stone-500 hover:text-stone-800">
          ← Library
        </Link>
        <h1 className="text-2xl font-semibold mt-2">{book.title}</h1>
        <p className="text-stone-600">{book.author}</p>
      </header>
      <ChatInterface bookId={book.id} authorName={book.author} />
    </main>
  );
}
