'use client';

import { useChat } from '@ai-sdk/react';
import { DefaultChatTransport } from 'ai';
import { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';

export default function ChatInterface({
  bookId,
  authorName,
}: {
  bookId: number;
  authorName: string;
}) {
  const [input, setInput] = useState('');
  const { messages, sendMessage, status } = useChat({
    transport: new DefaultChatTransport({
      api: '/api/chat',
      // The body customizer adds bookId to every request alongside messages.
      body: () => ({ bookId }),
    }),
  });

  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || status === 'streaming') return;
    sendMessage({ text: input });
    setInput('');
  };

  return (
    <>
      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-6 pr-2">
        {messages.length === 0 && (
          <div className="text-stone-400 text-sm italic">
            Ask {authorName} anything about the book.
          </div>
        )}
        {messages.map(m => (
          <div
            key={m.id}
            className={m.role === 'user' ? 'flex justify-end' : 'flex justify-start'}
          >
            <div
              className={
                m.role === 'user'
                  ? 'bg-stone-900 text-white rounded-2xl px-4 py-2 max-w-[80%]'
                  : 'prose prose-stone max-w-none'
              }
            >
              {m.parts.map((p, i) =>
                p.type === 'text' ? (
                  <ReactMarkdown
                    key={i}
                    remarkPlugins={[remarkMath]}
                    rehypePlugins={[rehypeKatex]}
                  >
                    {p.text}
                  </ReactMarkdown>
                ) : null
              )}
            </div>
          </div>
        ))}
        {status === 'streaming' && (
          <div className="text-stone-400 text-sm">…</div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="mt-4 pt-4 border-t border-stone-200">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder={`Ask ${authorName} a question…`}
            disabled={status === 'streaming'}
            className="flex-1 px-4 py-2 rounded-lg border border-stone-300 focus:outline-none focus:border-stone-500 disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={!input.trim() || status === 'streaming'}
            className="px-4 py-2 rounded-lg bg-stone-900 text-white disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Send
          </button>
        </div>
      </form>
    </>
  );
}
